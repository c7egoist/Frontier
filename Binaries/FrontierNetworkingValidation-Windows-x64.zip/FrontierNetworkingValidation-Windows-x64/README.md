# Frontier Networking Validation (Windows x64)

Cross-compiled Windows validation binaries for the Frontier networking workstream
(engine `NetworkingSession`, EOS/Photon provider adapters, `ReplicationCodec`
fragmentation, peer identity, the Everest “Networking” Quick Action toggle, and
the Quick Action active-disc rendering).

- Revision: eb5fafe (`arena/9335609b-frontier`)
- Toolchain: Zig 0.13.0 `x86_64-windows-gnu` cross-compile from Linux
  (`Automation/WindowsToolchain.cmake`), statically linked, no SDKs
  (`FRONTIER_EOS_SDK` / `FRONTIER_PHOTON_SDK` off, so the provider adapters run
  their honest no-SDK stubs)
- Date: 2026-11-05

## Contents

- `NetworkingProviderValidation.exe` — provider/session/codec/toggle checks
- `NetworkingSpaceValidation.exe` — record replication round-trip checks
- `ControlCentreValidation.exe` — UI control checks incl. the “Networking”
  Quick Action toggle disc
- `EngineContent/FontArchives/` — the 5 font families plus their OFL licences,
  required by `ControlCentreValidation.exe` (passed as its first argument)
- `RunValidations.bat` — runs all three and drops the evidence beside it

## Run

Double-click `RunValidations.bat`, or from a command prompt in this folder:

```bat
NetworkingProviderValidation.exe NetworkingProviderValidation.md
NetworkingSpaceValidation.exe NetworkingSpaceValidation.md
ControlCentreValidation.exe EngineContent\FontArchives control-centre-evidence
```

## Expected results

- `NetworkingProviderValidation.exe` exits 0 and ends with `45/45 passed`
  (the markdown ledger holds the full per-check table; Linux reference ledger:
  `Exhibits/Networking/Results/NetworkingProviderValidation.md`)
- `NetworkingSpaceValidation.exe` exits 0 and ends with `17/17 passed`
- `ControlCentreValidation.exe` exits 0 and prints a `PASS:` line

## Limitations

- Cross-compiled, not MSVC-built; launch behaviour on real Windows hardware is
  confirmed by running this package (that is its purpose)
- Provider adapters report `Unlinked` until EOS/Photon SDKs are linked in;
  `NetworkingLogin.exe` (EOS login + lobby) is built separately on Windows via
  `ToolchainSequence.ps1` and is not in this package
