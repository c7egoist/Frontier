@echo off
rem Runs the three Frontier networking validation binaries and leaves the
rem evidence next to this script. Every binary must exit with code 0.
set HERE=%~dp0
set FAILED=0
"%HERE%NetworkingProviderValidation.exe" "%HERE%NetworkingProviderValidation.md"
if errorlevel 1 set FAILED=1
"%HERE%NetworkingSpaceValidation.exe" "%HERE%NetworkingSpaceValidation.md"
if errorlevel 1 set FAILED=1
"%HERE%ControlCentreValidation.exe" "%HERE%EngineContent\FontArchives" "%HERE%control-centre-evidence"
if errorlevel 1 set FAILED=1
if %FAILED%==0 (
  echo ALL VALIDATIONS PASSED
) else (
  echo ONE OR MORE VALIDATIONS FAILED
  exit /b 1
)
