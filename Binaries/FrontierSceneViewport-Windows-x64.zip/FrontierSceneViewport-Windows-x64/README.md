# Frontier editor — Scene Viewport preview (Windows x64)

This folder runs as extracted. Keep `Frontier.exe`, `EngineContent/` and `Projects/` side by side.
`Package.json` lists anything left out of this download under `omitted`: the small download leaves out the Texture
Studio material archives, which the Scene Viewport does not read.

## Run

1. Start `Frontier.exe`. The Project Browser opens and lists **Project Everest**. The Zig build (`Package.json` →
   `toolchain`) also opens a console window with the log output; closing it closes the editor. The MSVC build has none.
2. Open Everest. The **Scene Viewport** panel brings up the live renderer. The first bring-up takes a while,
   because the distance volumes, surface cards and BVH are built from the scene. The panel shows the schematic and a
   status line until the first image is ready.
   - To skip the browser, run `Frontier.exe Projects\Everest\Everest.projectspace`, or drop the `.projectspace` file
     on `Frontier.exe`.
3. Camera controls, as in Unreal Engine's perspective viewport. The pointer hides during a drag and comes back
   where the drag began.

   | Input                                  | Camera                                                          |
   |----------------------------------------|-----------------------------------------------------------------|
   | hold right button, move the mouse      | look around in place                                            |
   | hold right button + W / S              | fly forward / back (also ↑ / ↓, numpad 8 / 2)                   |
   | hold right button + A / D              | fly left / right (also ← / →, numpad 4 / 6)                     |
   | hold right button + E / Q              | up / down in the world (also Page Up / Page Down, numpad 9 / 7) |
   | hold right button + R / F              | up / down along the view                                        |
   | hold right button + Z / C              | widen / narrow the field of view; it returns on release         |
   | hold right button + mouse wheel        | camera speed 1–8 (shown briefly at the bottom of the viewport)  |
   | Shift while flying                     | twice the speed                                                 |
   | hold left button, move the mouse       | forward / back over the ground and turn                         |
   | middle button, or left + right buttons | move sideways and up / down without turning                     |
   | mouse wheel                            | step forward / back (0.96 m per notch)                          |
   | Alt + left / right / middle drag       | orbit / dolly / track around a pivot ahead of the camera        |
   | F                                      | back to the level's starting view                               |
4. The viewport bar above the image is the VehicleHMI demo's:
   - the select switches the inspection view (Final image, Direct sun only, … the demo's 15). It is the
     `RenderPipeline` record's buffer index, so the Inspector shows the same choice;
   - **Particles** opens the level's particle editor;
   - the round buttons, also on keys: readout **H**, distance slice **I** (or **J**) and clean view **V**, which hides
     both. Respawn and Reassemble are greyed out, because this level has no vehicle and no breakable props;
   - the strip along the bottom of the window shows the frame rate, the refresh time, the quality, the sun, the camera
     position and the GPU.
5. Select the level's environment records in the Scene Directory and edit them in the Inspector:
   `Solar`, `OpticalFlare`, `Atmosphere` (with the four `Planet` entries under it: Venus, Jupiter, Mars, Saturn),
   `Clouds` (global/local), `Stars`, `Moons`, `Fog` (height/local), `AerialFog`, `Lightning`, `Wind` and
   `RenderPipeline`.
   - `RenderPipeline` quality tier 0/1/2 selects the demo's `low`/`medium`/`high` grade.
   - The hardware ray query (RTX) tier selects the ReSTIR path tracer. Turning it off selects the distance-field GI
     (GTX path). Changing a tier rebuilds the viewport.

## Environment controls in this build

The native inspector now includes the remaining VehicleHMI controls: Clouds/local cloud, Wind, Height Fog,
Atmospheric Fog, local fog, Lightning, Stars, four-slot Moon authoring and Lens Flare. Atmospheric Fog is its own
Scene Directory entry. The original Sun and Atmosphere pages are retained.

- Tabs, editable slider figures, keyboard/Shift-arrow diagrams, camera placement, catalogues and cross-record actions
  use native C++ controls. Changes are saved in the level container with the existing Save level / Ctrl+S action.
- Lens Flare **Export HDR** opens a path-entry modal and writes a 640 × 280 linear RGB PFM. It refuses an existing
  filename.
- The reference diagrams are not scene captures. Disabled controls explain missing native support; local media,
  lightning execution/audio, four-body Moon rendering and custom flare layers are not newly connected to the renderer.
- Native CPU checks pass, but this package has not been launched on Windows here. It is unsigned and not
  antivirus-scanned.
  Full visual parity across panel widths still needs acceptance review.

## What you are looking at

- The 1:1 C++/Vulkan/Slang port of the VehicleHMI demo's ReSTIR GI renders the demo's proving ground, without the car.
- The PlanetaryAtmosphere environment is drawn over it: atmosphere, sun, lens flare, volumetric clouds, height fog lit
  by
  the street lamps, moons, planets and Hipparcos stars.
- The environment also lights the scene. Its sun, filtered through its air, is the key light, and Luna and Ember take
  over at night. Its sky lights every bounce and reflection, its clouds shade the ground, and the buildings and posts
  shadow the sun shafts in the fog.
- Everything runs on the editor's own Vulkan 1.3 device and queue.
- Select **Environment · Solar** in the Outliner to open the demo's Sun page in the Inspector. It has four tabs:
  - **Overview:** drag the dial, use the presets, switch the Sunlight, Sun disc and Day cycle tiles.
  - **Daylight:** date, place and time. "Manual ↗" switches to "Time linked ↗", and the Day cycle runs the clock.
  - **Light & colour:** intensity, temperature or an RGB tint, and the spectrum reference.
  - **Disc & optics:** angular size and aureole, plus "Open Lens Flare ↗", which selects the flare.

  Every change applies live and is saved with the level.

## Requirements

- Windows 10/11 x64.
- A GPU and driver with Vulkan 1.3, dynamic rendering, scalar block layout and shader draw parameters.
- The RTX path needs `VK_KHR_ray_query` and acceleration structures. Without them, set the ray query tier off.

If the viewport cannot start, its status line says why. The same message is written to the Log Stream panel and to
the diagnostic journal.

## If it does not start

- The failure dialog names what was missing or refused, and the path of the diagnostic file:
  `%LOCALAPPDATA%\Frontier\Logs\Frontier-<number>.log`. That file is the most useful thing to send back.
- The journal records start-up, the Vulkan device, the project that opened and the Scene Viewport's first statuses
  (renderer, extent, refresh time), so a viewport problem on a particular GPU shows up there too.
- The Scene Viewport writes its bring-up into the same journal, one line per step (`[SceneViewport] bring-up ① facet
  space …` to `⑧ PlanetaryAtmosphere environment …`). A device failure names the Vulkan result and the step that was
  submitted (`device fault: …`). The first two refreshes are submitted step by step, so a fault there names its step.
- Keep the extracted folder together: `Frontier.exe` reads `EngineContent/ShaderArchives/Surface` (Project Browser),
  `GlobalIllumination` and `Environment` (Scene Viewport) beside itself.

## Not verified

- This build is **unsigned** and was **not antivirus-scanned**. Windows SmartScreen or the browser may warn about it.
  Do not turn protection off. If the download or start is blocked, build from source instead (see the repository's
  `Exhibits/SceneViewport/README.md`).
- `Package.json` → `toolchain` says how this copy was built: the repository's pinned Zig cross-toolchain on Linux, or
  MSVC. Releases on GitHub are launched on a GitHub Windows runner with a CPU Vulkan driver before they are published;
  the release notes carry that run's result and screenshots. No copy has been run on a hardware GPU by the authors, and
  all rendering evidence in the repository comes from CPU Vulkan drivers.
- Known gaps:
  - the drawn moon discs still follow the sun–moon geometry; the `Moons` record's phase sets Luna's light only;
  - viewport submissions are synchronous.

`Package.json` lists the source revision, the toolchain and a SHA-256 for every file.
